External Includes
================

Some files in this library are based off of other works. This file outlines their usage and licensing.

Included Footprint List
--------------
* `MPCIe_full_card.kicad_mod`: Copied from Tim 'mithro' Ansell's mini-pci-express KiCad project (licenses/mpcie_LICENSING)
* `MPCIe_half_card.kicad_mod`: Copied from Tim 'mithro' Ansell's mini-pci-express KiCad proect (licenses/mpcie_LICENSING)
* `MPCIe_socket.kicad_mod`: Copied from Tim 'mithro' Ansell's mini-pci-express KiCad project (licenses/mpcie_LICENSING)
