ATtiny24 3 LED Demo
===========================
Application: kicad
Version: 5.0.0-rc2-unknown-228881f~65~ubuntu18.04.1, release build

Nightly Development Builds

	sudo add-apt-repository --yes ppa:js-reynaud/ppa-kicad
	sudo apt update
	sudo apt install kicad



